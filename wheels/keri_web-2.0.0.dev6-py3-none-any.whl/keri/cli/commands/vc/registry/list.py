# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands module

"""
import argparse

from hio.base import doing
from hio.help import ogler

from ....common import Parsery, existingHby

from .....kering import ConfigurationError
from .....vdr import Regery


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='List credential registry names and identifiers', 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: list_registries(args))
parser.add_argument("--verbose", "-V", help="print JSON of all current events", action="store_true")


def list_registries(args):
    """ Command line list credential registries handler

    """
    kwa = dict(args=args)
    return [doing.doify(registries, **kwa)]


def registries(tymth, tock=0.0, **opts):
    _ = (yield tock)

    args = opts["args"]
    name = args.name
    base = args.base
    bran = args.bran

    try:
        with existingHby(name=name, base=base, bran=bran) as hby:
            rgy = Regery(hby=hby, name=name, base=base)
            for registry in rgy.regs.values():
                print(registry.name, ":", registry.regk, ":", registry.hab.pre)

    except ConfigurationError as e:
        print(f"identifier prefix for {name} does not exist, incept must be run first", )
        return -1

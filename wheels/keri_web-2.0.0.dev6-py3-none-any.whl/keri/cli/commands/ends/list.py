# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands module

"""
import argparse
import json

from hio.base import doing
from hio.help import ogler

from ...common import setupHby, Parsery

from ....kering import ConfigurationError


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='Add new endpoint role authorization.', 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: add_end(args))
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
parser.add_argument("--aid", help="qualified base64 of AID to export rpy messages for all endpoints.",
                    required=True)


def add_end(args):
    """ Command line tool for adding endpoint role authorizations

    """
    ld = RoleDoer(name=args.name,
                  base=args.base,
                  alias=args.alias,
                  bran=args.bran,
                  aid=args.aid)
    return [ld]


class RoleDoer(doing.DoDoer):

    def __init__(self, name, base, alias, bran, aid):
        self.hby = setupHby(name=name, base=base, bran=bran)
        self.hab = self.hby.habByName(alias)
        if self.hab is None:
            raise ConfigurationError(f"unknown alias={alias}")

        self.aid = aid
        doers = [doing.doify(self.roleDo)]

        super(RoleDoer, self).__init__(doers=doers)

    def roleDo(self, tymth, tock=0.0, **kwa):
        """ Export any end reply messages previous saved for the provided AID

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method

        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        ends = self.hab.endsFor(self.aid)
        print(json.dumps(ends, indent=1))
        return

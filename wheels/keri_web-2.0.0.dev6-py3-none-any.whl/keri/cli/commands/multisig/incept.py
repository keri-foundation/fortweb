# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands.multisig module

"""

import argparse
import json
from json import JSONDecodeError
from ordered_set import OrderedSet as oset

import sys
from hio.base import doing
from hio.help import ogler

from ....kering import ConfigurationError, Kinds, Versionage
from ....app import (Notifier, MailboxDirector, Multiplexor,
                     Counselor, HaberyDoer, Poster,
                     multisigInceptExn)
from ....app.grouping import loadHandlers
from ...common import Parsery, setupHby, printIdentifier, parseVersion
from ....core import Prefixer, Number, Diger
from ....peer import Exchanger

logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='Initialize a group identifier prefix',
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: inceptMultisig(args))
parser.add_argument('--alias', '-a', help='human readable alias for the local identifier prefix', required=True)
parser.add_argument("--wait", "-w", help="number of seconds to wait for other multisig events, defaults to 10",
                    default=10)

parser.add_argument('--group', '-g', help="Human readable environment reference for group identifier", required=True)
parser.add_argument('--file', '-f', help='Filename to use to create the identifier', default="", required=True)
parser.add_argument('--version', default=None, required=False, type=parseVersion,
                    help='KERI protocol version for the group inception event, such as 1.0 or 2.0')


def normalizeOptions(opts):
    """
    Normalize JSON-loaded multisig inception options.
    """
    if isinstance(opts.get("version"), (list, tuple)):
        opts["version"] = Versionage(*opts["version"])
    return opts


def inceptMultisig(args):
    """
    Reads the config file into a MultiSigInceptOptions dataclass and creates and signs the inception
    event for the group identifier.  If signatures are provided in the options file, the event is submitted
    to its witnesses and receipts are collected.

    Parameters:
        args: Parsed arguments from the command line

    """

    # help.ogler.level = logging.INFO
    # help.ogler.reopen(name=args.name, temp=True, clear=True)

    try:
        with open(args.file) as f:
            opts = normalizeOptions(json.load(f))
    except FileNotFoundError:
        print("config file", args.file, "not found")
        sys.exit(-1)
    except JSONDecodeError:
        print("config file", args.file, "not valid JSON")
        sys.exit(-1)

    if args.version is not None:
        opts["version"] = args.version

    name = args.name
    alias = args.alias
    base = args.base
    bran = args.bran
    group = args.group

    icpDoer = GroupMultisigIncept(name=name, base=base, alias=alias, bran=bran, group=group, wait=args.wait, **opts)

    doers = [icpDoer]
    return doers


class GroupMultisigIncept(doing.DoDoer):

    def __init__(self, name, base, alias, bran, group, wait, version=None, **kwa):
        self.name = name
        self.version = version
        self.hby = setupHby(name=name, base=base, bran=bran, version=self.version)
        self.hbyDoer = HaberyDoer(habery=self.hby)  # setup doer

        self.alias = alias
        self.inits = dict(kwa)
        if self.version is not None:
            self.inits["version"] = self.version
        self.group = group
        self.wait = wait
        init_kind = self.inits.get("kind", Kinds.json)

        topics = ['/receipt', '/multisig', '/replay']
        if "delpre" in self.inits:
            topics.append('/delegate')

        notifier = Notifier(self.hby)
        mux = Multiplexor(self.hby, notifier=notifier)
        exc = Exchanger(hby=self.hby, handlers=[])
        loadHandlers(exc, mux)
        self.mux = mux
        if self.version is not None:
            self.mbx = MailboxDirector(hby=self.hby, topics=topics, exc=exc,
                                       version=self.version, gvrsn=self.version,
                                       kind=init_kind)
        else:
            self.mbx = MailboxDirector(hby=self.hby, topics=topics, exc=exc)
        self.counselor = Counselor(hby=self.hby,
                                   version=self.version,
                                   kind=init_kind)
        self.postman = Poster(hby=self.hby, version=self.version,
                              kind=init_kind)

        doers = [self.hbyDoer, self.mbx, self.counselor, self.postman]
        self.toRemove = list(doers)

        doers.extend([doing.doify(self.inceptDo)])

        super(GroupMultisigIncept, self).__init__(doers=doers)

    def inceptDo(self, tymth, tock=0.0, **kwa):
        """ Create or participate in an inception event for a distributed multisig identifier

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        hab = self.hby.habByName(name=self.alias)
        if hab is None:
            raise ConfigurationError(f"invalid alias {self.alias} "
                                     f"specified for database {self.name}")

        ghab = self.hby.habByName(name=self.group)
        if ghab is None:
            smids = self.inits["aids"]  # not a pass through in makeGroupHab
            if "rmids" in self.inits:
                rmids = self.inits["rmids"]
                del self.inits['rmids']
            else:
                rmids = None

            del self.inits["aids"]

            ghab = self.hby.makeGroupHab(group=self.group, mhab=hab, smids=smids,
                                         rmids=rmids, **self.inits)

            icp = ghab.msgOwnInception(allowPartiallySigned=True)

            # Create a notification EXN message to send to the other agents
            exn, ims = multisigInceptExn(ghab.mhab,
                                         smids=ghab.smids,
                                         rmids=ghab.rmids,
                                         icp=icp,
                                         version=self.inits.get("version"),
                                         kind=self.inits.get("kind", Kinds.json))
            others = list(oset(smids + (rmids or [])))

            others.remove(ghab.mhab.pre)

            for recpt in others:  # this goes to other participants only as a signaling mechanism
                self.postman.send(src=ghab.mhab.pre,
                                  dest=recpt,
                                  topic="multisig",
                                  serder=exn,
                                  attachment=ims)

            logger.info(f"Group identifier inception initialized for {ghab.pre}")
            prefixer = Prefixer(qb64=ghab.pre)
            number = Number(sn=0)
            diger = Diger(qb64=prefixer.qb64)
            self.counselor.start(prefixer=prefixer, number=number, diger=diger,
                                 ghab=ghab)

        else:
            prefixer = Prefixer(qb64=ghab.pre)
            number = Number(sn=0)

        while True:
            saider = self.hby.db.cgms.get(keys=(prefixer.qb64, number.qb64))
            if saider is not None:
                break

            yield self.tock

        if ghab.kever.delpre:
            yield from self.postman.sendEventToDelegator(hab=ghab, sender=ghab.mhab, fn=ghab.kever.sn)

        print()
        printIdentifier(self.hby, ghab.pre)
        self.remove(self.toRemove)
